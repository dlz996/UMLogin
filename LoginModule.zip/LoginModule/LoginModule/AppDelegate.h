//
//  AppDelegate.h
//  LoginModule
//
//  Created by 董立峥 on 2017/5/8.
//  Copyright © 2017年 芦苇科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

