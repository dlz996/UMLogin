//
//  UMSocialUniqueIdHandler.h
//  U-Share
//
//  Created by umeng on 17/1/1.
//  Copyright © 2016年 umeng. All rights reserved.
//
#import <Foundation/Foundation.h>


/**
 获取IDFA插件
 */
@interface UMSocialUniqueIdHandler : NSObject

@end
